import * as L from 'leaflet'

// Constantes
const dataUpdateInterval = 1000 * 60 * 5      // 5 minutes
const mapInitialView = [48.856586, 2.344979]  // Paris
const mapInitialZoom = 12

// https://github.com/Leaflet/Leaflet/issues/4968
delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  shadowUrl: require('leaflet/dist/images/marker-shadow.png')
})

function updateDataOnMap (data, myMap, popups) {
  for (const record of data.records) {
    if (record.fields.hasOwnProperty('name')) {
      let content = `${record.fields.name}<br/> il reste ${record.fields.numbikesavailable} vélo(s) <br/> capaciter ${record.fields.capacity}`
      if (popups.has(record.fields.station_id)) {
        let popup = popups.get(record.fields.station_id)
        popup.setContent(content)
        popup.update()
      } else {
        let marker = L.marker(record.fields.xy).addTo(myMap)
        let popup = L.popup().setContent(content)
        marker.bindPopup(popup)
        popups.set(record.fields.station_id, popup)
      }
    }
  }
}

function getData ({ rows = 5, sort = 'capacity' } = {}, handle) {
  const url = `https://opendata.paris.fr/api/records/1.0/search/?dataset=velib-disponibilite-en-temps-reel&sort=${sort}&rows=${rows}`
  let xhr = new window.XMLHttpRequest()
  xhr.onload = function (event) {
    if (this.status === 200) {
      let data = JSON.parse(this.responseText)
      handle(data)
    }
  }

  xhr.onerror = function (event) {
    console.log(`Une erreur ${event.target.status} s'est produite au cours de la réception du document.`)
  }

  xhr.open('GET', url)
  xhr.send(null)

  window.setTimeout(getData, dataUpdateInterval, {rows, sort}, handle) // Update toute les 5 minutes
}

function init () {
  var myMap = null
  myMap = L.map('mymapid').setView(mapInitialView, mapInitialZoom)
  L.tileLayer(
    'https://wxs.ign.fr/ld0jgrlpaway88fw6u4x3h38/geoportail/wmts?service=WMTS&request=GetTile&version=1.0.0&tilematrixset=PM&tilematrix={z}&tilecol={x}&tilerow={y}&layer=ORTHOIMAGERY.ORTHOPHOTOS&format=image/jpeg&style=normal',
    {
      minZoom: 0,
      maxZoom: 18,
      tileSize: 256,
      attribution: 'IGN-F/Géoportail'
    }).addTo(myMap)

  var popups = new Map()
  getData({rows: 300}, data => updateDataOnMap(data, myMap, popups))
}

window.addEventListener('load', init)